import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./UserLayout.css";

function UserLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error("Error loading user in layout:", e);
      }
    }
  }, []);

  const menuItems = [
    { name: "Home", icon: "⌂", path: "/home" },
    { name: "Chat", icon: "✦", path: "/chat" },
    { name: "Chat History", icon: "◷", path: "/history" },
    { name: "Notifications", icon: "♢", path: "/notifications" },
  ];

  const knowledgeItems = [
    { name: "Company", icon: "▣", path: "/company" },
    { name: "Products & Services", icon: "▤", path: "/products" },
    { name: "FAQs", icon: "?", path: "/faqs" },
    { name: "Documents", icon: "▧", path: "/documents" },
  ];

  const isActive = (path) => location.pathname === path;

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  const initial = user && user.name ? user.name[0].toUpperCase() : "A";
  const displayName = user ? user.name : "Guest User";
  const displaySubtext = user ? user.email : "User";

  return (
    <div className="user-layout">

      {/* SIDEBAR */}
      <aside className="user-sidebar">

        {/* Logo */}
        <div className="sidebar-brand">
          <div className="sidebar-logo">A</div>

          <div>
            <h2>Apically</h2>
            <span>AI Assistant</span>
          </div>
        </div>

        {/* New Chat */}
        <Link to="/chat" className="new-chat-button">
          <span>＋</span>
          New Chat
        </Link>

        {/* Main Navigation */}
        <div className="sidebar-section">

          <p className="sidebar-title">
            Workspace
          </p>

          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`sidebar-link ${
                isActive(item.path) ? "active" : ""
              }`}
            >
              <span className="sidebar-icon">
                {item.icon}
              </span>

              {item.name}
            </Link>
          ))}

        </div>

        {/* Knowledge Base */}
        <div className="sidebar-section">

          <p className="sidebar-title">
            Knowledge Base
          </p>

          {knowledgeItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`sidebar-link ${
                isActive(item.path) ? "active" : ""
              }`}
            >
              <span className="sidebar-icon">
                {item.icon}
              </span>

              {item.name}
            </Link>
          ))}

        </div>

        {/* Bottom Navigation */}
        <div className="sidebar-bottom">

          <Link
            to="/settings"
            className={`sidebar-link ${
              isActive("/settings") ? "active" : ""
            }`}
          >
            <span className="sidebar-icon">⚙</span>
            Settings
          </Link>

          <div className="sidebar-user">

            <Link to="/profile" className="user-info">

              <div className="user-avatar">
                {initial}
              </div>

              <div className="user-details">
                <strong>{displayName}</strong>
                <span style={{ overflow: "hidden", textOverflow: "ellipsis", maxWidth: "120px", display: "inline-block" }}>{displaySubtext}</span>
              </div>

            </Link>

            <button
              className="logout-button"
              onClick={handleLogout}
              title="Logout"
            >
              ↪
            </button>

          </div>

        </div>

      </aside>

      {/* MAIN CONTENT */}
      <main className="user-content">

        <div className="mobile-topbar">

          <div className="mobile-brand">
            <div className="sidebar-logo">A</div>
            <strong>Apically</strong>
          </div>

          <Link to="/profile" className="mobile-avatar">
            {initial}
          </Link>

        </div>

        <Outlet />

      </main>

    </div>
  );
}

export default UserLayout;