import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Register from "./pages/Register";

import UserLayout from "./components/UserLayout";

import Home from "./pages/Home";
import Chat from "./pages/Chat";
import ChatHistory from "./pages/ChatHistory";
import Feedback from "./pages/Feedback";
import Notifications from "./pages/Notifications";
import Profile from "./pages/Profile";
import Products from "./pages/Products";
import FAQs from "./pages/FAQs";
import Documents from "./pages/Documents";
import Settings from "./pages/Settings";

import "./App.css";

function App() {
  return (
    <BrowserRouter>

      <Routes>

        {/* PUBLIC PAGES */}

        <Route path="/login" element={<Login />} />

        <Route path="/register" element={<Register />} />


        {/* USER SIDE */}

        <Route element={<UserLayout />}>

          <Route path="/home" element={<Home />} />

          <Route path="/chat" element={<Chat />} />

          <Route path="/history" element={<ChatHistory />} />

          <Route path="/feedback" element={<Feedback />} />

          <Route path="/notifications" element={<Notifications />} />

          <Route path="/profile" element={<Profile />} />

          <Route path="/products" element={<Products />} />

          <Route path="/faqs" element={<FAQs />} />

          <Route path="/documents" element={<Documents />} />

          <Route path="/settings" element={<Settings />} />

        </Route>


        {/* DEFAULT */}

        <Route
          path="/"
          element={<Navigate to="/login" replace />}
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;