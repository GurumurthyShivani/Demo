import { Link } from "react-router-dom";
import "./Products.css";

function Products() {
  const products = [
    {
      icon: "🤖",
      title: "AI Solutions",
      description:
        "AI-powered solutions designed to automate tasks and improve business productivity.",
      category: "AI & Technology",
    },
    {
      icon: "💻",
      title: "Software Development",
      description:
        "Modern software applications built according to business requirements.",
      category: "Development",
    },
    {
      icon: "☁️",
      title: "Cloud Services",
      description:
        "Scalable cloud solutions for applications, data and business operations.",
      category: "Cloud",
    },
    {
      icon: "📊",
      title: "Business Analytics",
      description:
        "Data-driven insights that help businesses understand performance and trends.",
      category: "Analytics",
    },
    {
      icon: "🔐",
      title: "Security Solutions",
      description:
        "Technology solutions designed to protect applications, systems and data.",
      category: "Security",
    },
    {
      icon: "🛠️",
      title: "Technical Support",
      description:
        "Technical assistance and support for products, applications and services.",
      category: "Support",
    },
  ];

  return (
    <div className="products-page">

      {/* Header */}
      <header className="products-header">

        <div className="products-brand">

          <Link to="/home" className="products-back">
            ←
          </Link>

          <div className="products-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>
            <span>AI Assistant</span>
          </div>

        </div>

        <div className="products-actions">

          <Link to="/chat" className="products-chat-btn">
            Ask AI
          </Link>

          <Link to="/profile" className="products-avatar">
            A
          </Link>

        </div>

      </header>

      {/* Main */}
      <main className="products-main">

        <section className="products-intro">

          <span className="products-label">
            PRODUCTS & SERVICES
          </span>

          <h1>
            Explore our products and services
          </h1>

          <p>
            Discover the solutions and services available through
            our company. Ask Apically for more information about
            any product.
          </p>

        </section>

        {/* Products */}
        <section className="products-section">

          <div className="products-section-heading">
            <div>
              <h2>Our Solutions</h2>
              <p>
                Explore our technology and business solutions.
              </p>
            </div>

            <span>
              {products.length} solutions
            </span>
          </div>

          <div className="products-grid">

            {products.map((product) => (

              <div
                className="product-card"
                key={product.title}
              >

                <div className="product-card-top">

                  <div className="product-icon">
                    {product.icon}
                  </div>

                  <span className="product-category">
                    {product.category}
                  </span>

                </div>

                <h3>
                  {product.title}
                </h3>

                <p>
                  {product.description}
                </p>

                <Link to="/chat">
                  Ask Apically →
                </Link>

              </div>

            ))}

          </div>

        </section>

        {/* CTA */}
        <section className="products-cta">

          <div>
            <span>Need more information?</span>

            <h2>
              Ask Apically about our products
            </h2>

            <p>
              Get answers about features, services, availability
              and other product-related information.
            </p>
          </div>

          <Link to="/chat">
            Start a Conversation →
          </Link>

        </section>

      </main>

    </div>
  );
}

export default Products;