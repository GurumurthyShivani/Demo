import { useState } from "react";
import { Link } from "react-router-dom";
import "./Feedback.css";

function Feedback() {
  const [rating, setRating] = useState("");
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!rating) {
      alert("Please select Helpful or Not Helpful.");
      return;
    }

    console.log({
      rating,
      comment,
    });

    setSubmitted(true);
  };

  return (
    <div className="feedback-page">

      <header className="feedback-header">

        <div className="feedback-brand">

          <Link to="/home" className="feedback-back">
            ←
          </Link>

          <div className="feedback-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>
            <span>AI Assistant</span>
          </div>

        </div>

        <Link to="/chat" className="feedback-chat-link">
          Back to Chat
        </Link>

      </header>

      <main className="feedback-main">

        {!submitted ? (
          <div className="feedback-card">

            <div className="feedback-icon">
              💬
            </div>

            <h1>Share your feedback</h1>

            <p>
              Your feedback helps us improve the Apically AI Assistant.
            </p>

            <form onSubmit={handleSubmit}>

              <div className="feedback-question">
                Was this answer helpful?
              </div>

              <div className="feedback-options">

                <button
                  type="button"
                  className={`feedback-option ${
                    rating === "helpful" ? "selected" : ""
                  }`}
                  onClick={() => setRating("helpful")}
                >
                  👍
                  <span>Helpful</span>
                </button>

                <button
                  type="button"
                  className={`feedback-option ${
                    rating === "not-helpful" ? "selected" : ""
                  }`}
                  onClick={() => setRating("not-helpful")}
                >
                  👎
                  <span>Not Helpful</span>
                </button>

              </div>

              <div className="feedback-field">

                <label>
                  Additional comments
                </label>

                <textarea
                  placeholder="Tell us how we can improve..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows="5"
                />

              </div>

              <button
                type="submit"
                className="feedback-submit"
              >
                Submit Feedback
              </button>

            </form>

          </div>
        ) : (

          <div className="feedback-success">

            <div className="success-icon">
              ✓
            </div>

            <h1>Thank you!</h1>

            <p>
              Your feedback has been submitted successfully.
            </p>

            <Link to="/chat">
              Continue Chatting
            </Link>

          </div>

        )}

      </main>

    </div>
  );
}

export default Feedback;