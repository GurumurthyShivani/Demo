import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import "./ChatHistory.css";

function ChatHistory() {
  const [search, setSearch] = useState("");
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    let userId = null;
    if (savedUser) {
      try {
        userId = JSON.parse(savedUser).id;
      } catch (e) {}
    }
    fetchHistory(userId);
  }, []);

  const fetchHistory = async (userId) => {
    try {
      const url = userId ? `http://127.0.0.1:8000/api/history/?user_id=${userId}` : "http://127.0.0.1:8000/api/history/";
      const res = await fetch(url);
      if (!res.ok) return;
      const data = await res.json();
      
      if (data.history) {
        const mapped = data.history.map((item) => ({
          id: item.id,
          title: item.user_message.length > 30 ? item.user_message.substring(0, 30) + "..." : item.user_message,
          preview: item.bot_reply.length > 50 ? item.bot_reply.substring(0, 50) + "..." : item.bot_reply,
          date: item.created_at.split(" ")[0],
          time: item.created_at.split(" ")[1] || "",
          messages: 2,
        }));
        setConversations(mapped);
      }
    } catch (err) {
      console.error("Error fetching history:", err);
    } finally {
      setLoading(false);
    }
  };

  const deleteConversation = async (id) => {
    setConversations(conversations.filter((conversation) => conversation.id !== id));
  };

  const filteredConversations = conversations.filter((conversation) =>
    conversation.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="history-page">

      {/* Header */}
      <header className="history-header">

        <div className="history-brand">

          <Link to="/home" className="history-back">
            ←
          </Link>

          <div className="history-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>
            <span>AI Assistant</span>
          </div>

        </div>

        <div className="history-actions">

          <Link to="/chat" className="new-chat-btn">
            + New Chat
          </Link>

          <Link to="/profile" className="history-avatar">
            A
          </Link>

        </div>

      </header>

      {/* Main */}
      <main className="history-main">

        <div className="history-title">

          <div>
            <h1>Chat History</h1>

            <p>
              View and manage your previous conversations.
            </p>
          </div>

        </div>

        {/* Search */}
        <div className="history-search">

          <span>⌕</span>

          <input
            type="text"
            placeholder="Search conversations..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

        </div>

        {/* Conversation List */}
        <div className="history-list">

          {filteredConversations.length > 0 ? (

            filteredConversations.map((conversation) => (

              <div
                className="history-item"
                key={conversation.id}
              >

                <Link
                  to="/chat"
                  className="history-item-main"
                >

                  <div className="history-chat-icon">
                    💬
                  </div>

                  <div className="history-chat-content">

                    <h3>
                      {conversation.title}
                    </h3>

                    <p>
                      {conversation.preview}
                    </p>

                    <div className="history-meta">

                      <span>
                        {conversation.date}
                      </span>

                      <span>•</span>

                      <span>
                        {conversation.time}
                      </span>

                      <span>•</span>

                      <span>
                        {conversation.messages} messages
                      </span>

                    </div>

                  </div>

                </Link>

                <button
                  className="delete-history-btn"
                  onClick={() =>
                    deleteConversation(conversation.id)
                  }
                  title="Delete conversation"
                >
                  🗑
                </button>

              </div>

            ))

          ) : (

            <div className="empty-history">

              <div className="empty-history-icon">
                💬
              </div>

              <h2>No conversations found</h2>

              <p>
                Try another search or start a new conversation.
              </p>

              <Link to="/chat">
                Start New Chat
              </Link>

            </div>

          )}

        </div>

      </main>

    </div>
  );
}

export default ChatHistory;