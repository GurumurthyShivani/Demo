import { useState } from "react";
import { Link } from "react-router-dom";
import "./Notifications.css";

function Notifications() {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: "message",
      icon: "💬",
      title: "New AI response",
      message: "Apically has completed your latest request.",
      time: "10 minutes ago",
      read: false,
    },
    {
      id: 2,
      type: "system",
      icon: "🔔",
      title: "System notification",
      message: "Your Apically account is active and ready to use.",
      time: "1 hour ago",
      read: false,
    },
    {
      id: 3,
      type: "system",
      icon: "📢",
      title: "Apically update",
      message: "New knowledge and FAQ information is available.",
      time: "Yesterday",
      read: true,
    },
  ]);

  const markAsRead = (id) => {
    setNotifications((previous) =>
      previous.map((notification) =>
        notification.id === id
          ? { ...notification, read: true }
          : notification
      )
    );
  };

  const deleteNotification = (id) => {
    setNotifications((previous) =>
      previous.filter((notification) => notification.id !== id)
    );
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter(
    (notification) => !notification.read
  ).length;

  return (
    <div className="notifications-page">

      {/* Header */}
      <header className="notifications-header">

        <div className="notifications-brand">

          <Link to="/home" className="notifications-back">
            ←
          </Link>

          <div className="notifications-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>
            <span>AI Assistant</span>
          </div>

        </div>

        <Link to="/profile" className="notifications-avatar">
          A
        </Link>

      </header>

      {/* Main */}
      <main className="notifications-main">

        <div className="notifications-title">

          <div>
            <h1>Notifications</h1>

            <p>
              Stay updated with your Apically activity.
            </p>
          </div>

          {notifications.length > 0 && (
            <button
              className="clear-all-btn"
              onClick={clearAll}
            >
              Clear All
            </button>
          )}

        </div>

        {/* Notification summary */}
        <div className="notification-summary">

          <div className="summary-icon">
            🔔
          </div>

          <div>
            <strong>
              {unreadCount} unread notification
              {unreadCount !== 1 ? "s" : ""}
            </strong>

            <p>
              You have {notifications.length} total notification
              {notifications.length !== 1 ? "s" : ""}.
            </p>
          </div>

        </div>

        {/* Notifications */}
        <div className="notification-list">

          {notifications.length > 0 ? (

            notifications.map((notification) => (

              <div
                key={notification.id}
                className={`notification-item ${
                  notification.read ? "read" : "unread"
                }`}
              >

                <div className="notification-icon">
                  {notification.icon}
                </div>

                <div className="notification-content">

                  <h3>
                    {notification.title}
                  </h3>

                  <p>
                    {notification.message}
                  </p>

                  <span>
                    {notification.time}
                  </span>

                </div>

                <div className="notification-actions">

                  {!notification.read && (
                    <button
                      onClick={() =>
                        markAsRead(notification.id)
                      }
                      title="Mark as read"
                    >
                      ✓
                    </button>
                  )}

                  <button
                    onClick={() =>
                      deleteNotification(notification.id)
                    }
                    title="Delete notification"
                  >
                    🗑
                  </button>

                </div>

              </div>

            ))

          ) : (

            <div className="empty-notifications">

              <div className="empty-notification-icon">
                🔔
              </div>

              <h2>No notifications</h2>

              <p>
                You're all caught up.
              </p>

            </div>

          )}

        </div>

      </main>

    </div>
  );
}

export default Notifications;