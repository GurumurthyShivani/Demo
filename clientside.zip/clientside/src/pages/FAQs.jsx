import { useState } from "react";
import { Link } from "react-router-dom";
import "./FAQs.css";

function FAQs() {
  const [search, setSearch] = useState("");
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      category: "General",
      question: "What is Apically?",
      answer:
        "Apically is an AI-powered assistant that helps users get information about the company, products, services, FAQs and documents."
    },
    {
      category: "General",
      question: "How does Apically work?",
      answer:
        "Apically understands your question and generates a relevant response using the company's knowledge base and AI services."
    },
    {
      category: "Products",
      question: "What products and services does the company provide?",
      answer:
        "You can explore the available products and services from the Products & Services section."
    },
    {
      category: "Chat",
      question: "Can I view my previous conversations?",
      answer:
        "Yes. Your previous conversations can be accessed from the Chat History section."
    },
    {
      category: "Chat",
      question: "Can I provide feedback about an answer?",
      answer:
        "Yes. You can mark an answer as Helpful or Not Helpful and optionally provide a comment."
    },
    {
      category: "Security",
      question: "Is my account protected?",
      answer:
        "Apically is designed to use authentication, role-based access and secure session management. Actual security enforcement will be handled by the backend."
    }
  ];

  const filteredFAQs = faqs.filter((faq) =>
    `${faq.question} ${faq.answer} ${faq.category}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div className="faqs-page">

      <header className="faqs-header">
        <div className="faqs-brand">
          <Link to="/home" className="faqs-back">←</Link>

          <div className="faqs-logo">A</div>

          <div>
            <h2>Apically</h2>
            <span>Frequently Asked Questions</span>
          </div>
        </div>

        <Link to="/chat" className="faq-chat-button">
          Ask Apically
        </Link>
      </header>

      <main className="faqs-main">

        <section className="faqs-intro">
          <div className="faq-intro-icon">?</div>

          <div>
            <p>Knowledge Base</p>
            <h1>Frequently Asked Questions</h1>
            <span>
              Find quick answers to common questions about Apically.
            </span>
          </div>
        </section>

        <div className="faq-search">
          <span>⌕</span>

          <input
            type="text"
            placeholder="Search frequently asked questions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <section className="faq-list">

          {filteredFAQs.length > 0 ? (
            filteredFAQs.map((faq, index) => (
              <div className="faq-card" key={index}>

                <button
                  className="faq-question"
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                >
                  <div>
                    <span className="faq-category">
                      {faq.category}
                    </span>

                    <h3>{faq.question}</h3>
                  </div>

                  <span className="faq-arrow">
                    {openIndex === index ? "−" : "+"}
                  </span>
                </button>

                {openIndex === index && (
                  <div className="faq-answer">
                    {faq.answer}
                  </div>
                )}

              </div>
            ))
          ) : (
            <div className="faq-empty">
              <div>🔍</div>
              <h3>No FAQs found</h3>
              <p>
                Try searching with a different keyword or ask Apically.
              </p>

              <Link to="/chat">
                Ask Apically →
              </Link>
            </div>
          )}

        </section>

      </main>
    </div>
  );
}

export default FAQs;