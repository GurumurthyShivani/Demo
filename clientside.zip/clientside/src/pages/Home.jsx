import { Link } from "react-router-dom";
import "./Home.css";

function Home() {
  const features = [
    {
      icon: "🏢",
      title: "Company Information",
      description: "Learn about our company, mission and services.",
      path: "/company",
    },
    {
      icon: "📦",
      title: "Products & Services",
      description: "Explore our products and available services.",
      path: "/products",
    },
    {
      icon: "❓",
      title: "FAQs",
      description: "Find answers to frequently asked questions.",
      path: "/faqs",
    },
    {
      icon: "📄",
      title: "Documents",
      description: "Get information from company documents and PDFs.",
      path: "/documents",
    },
  ];

  return (
    <div className="home-page">

      {/* Header */}
      <header className="home-header">

        <div className="home-brand">
          <div className="home-logo">A</div>

          <div>
            <h2>Apically</h2>
            <span>AI Assistant</span>
          </div>
        </div>

        <div className="home-header-actions">
          <Link to="/notifications" className="notification-btn">
            🔔
          </Link>

          <Link to="/profile" className="home-avatar">
            A
          </Link>
        </div>

      </header>

      {/* Main */}
      <main className="home-main">

        <section className="welcome-section">

          <div className="welcome-icon">
            ✦
          </div>

          <div>
            <p className="welcome-small">
              Welcome back
            </p>

            <h1>
              How can Apically help you today?
            </h1>

            <p className="welcome-description">
              Ask questions about our company, products, services,
              FAQs or documents.
            </p>
          </div>

        </section>

        {/* Chat CTA */}
        <section className="chat-banner">

          <div>
            <span className="online-label">
              <span></span>
              AI Assistant Online
            </span>

            <h2>
              Start a conversation with Apically
            </h2>

            <p>
              Get quick answers using our AI-powered assistant.
            </p>
          </div>

          <Link to="/chat" className="start-chat-btn">
            Start New Chat →
          </Link>

        </section>

        {/* Knowledge Cards */}
        <section className="home-section">

          <div className="section-heading">
            <div>
              <h2>Explore Apically</h2>
              <p>
                Quickly access company information and knowledge.
              </p>
            </div>
          </div>

          <div className="feature-grid">

            {features.map((feature) => (
              <Link
                to={feature.path}
                className="feature-card"
                key={feature.title}
              >

                <div className="feature-icon">
                  {feature.icon}
                </div>

                <div className="feature-content">
                  <h3>{feature.title}</h3>

                  <p>
                    {feature.description}
                  </p>
                </div>

                <span className="feature-arrow">
                  →
                </span>

              </Link>
            ))}

          </div>

        </section>

        {/* Recent Conversations */}
        <section className="home-section">

          <div className="section-heading">
            <div>
              <h2>Recent Conversations</h2>
              <p>Your latest conversations with Apically.</p>
            </div>

            <Link to="/history">
              View All →
            </Link>
          </div>

          <div className="conversation-list">

            <div className="conversation-item">

              <div className="conversation-icon">
                💬
              </div>

              <div>
                <h3>Product information</h3>
                <p>
                  Yesterday · 4 messages
                </p>
              </div>

              <span>→</span>

            </div>

            <div className="conversation-item">

              <div className="conversation-icon">
                💬
              </div>

              <div>
                <h3>Company details</h3>
                <p>
                  2 days ago · 6 messages
                </p>
              </div>

              <span>→</span>

            </div>

          </div>

        </section>

      </main>

    </div>
  );
}

export default Home;