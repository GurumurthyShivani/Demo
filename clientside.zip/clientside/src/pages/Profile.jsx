import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Profile.css";

function Profile() {
  const navigate = useNavigate();

  const [name, setName] = useState("Apically User");
  const [email, setEmail] = useState("user@example.com");
  const [role] = useState("Member");
  const [user, setUser] = useState(null);

  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
        setName(parsed.name || "Apically User");
        setEmail(parsed.email || "user@example.com");
      } catch (e) {
        console.error("Error loading user profile:", e);
      }
    }
  }, []);

  const handleSave = (e) => {
    e.preventDefault();

    const updatedUser = { ...user, name, email };
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));

    setEditing(false);
    setSaved(true);

    setTimeout(() => {
      setSaved(false);
    }, 2500);
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className="profile-page">

      {/* Header */}
      <header className="profile-header">

        <div className="profile-brand">

          <Link to="/home" className="profile-back">
            ←
          </Link>

          <div className="profile-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>
            <span>AI Assistant</span>
          </div>

        </div>

        <Link to="/notifications" className="profile-notification">
          🔔
        </Link>

      </header>

      {/* Main */}
      <main className="profile-main">

        <div className="profile-title">
          <h1>My Profile</h1>

          <p>
            Manage your Apically account information.
          </p>
        </div>

        {saved && (
          <div className="profile-success">
            ✓ Profile updated successfully.
          </div>
        )}

        <div className="profile-grid">

          {/* Profile Card */}
          <section className="profile-card">

            <div className="profile-card-header">

              <div className="large-avatar">
                {name.charAt(0).toUpperCase()}
              </div>

              <div>
                <h2>{name}</h2>
                <p>{role}</p>
              </div>

            </div>

            <div className="account-status">
              <span></span>
              Active Account
            </div>

          </section>

          {/* Information */}
          <section className="profile-card">

            <div className="profile-section-heading">

              <div>
                <h2>Personal Information</h2>
                <p>
                  Your account details
                </p>
              </div>

              {!editing && (
                <button
                  className="edit-profile-btn"
                  onClick={() => setEditing(true)}
                >
                  Edit
                </button>
              )}

            </div>

            <form onSubmit={handleSave}>

              <div className="profile-field">

                <label>Full Name</label>

                <input
                  type="text"
                  value={name}
                  disabled={!editing}
                  onChange={(e) => setName(e.target.value)}
                />

              </div>

              <div className="profile-field">

                <label>Email Address</label>

                <input
                  type="email"
                  value={email}
                  disabled
                />

              </div>

              <div className="profile-field">

                <label>Role</label>

                <input
                  type="text"
                  value={role}
                  disabled
                />

              </div>

              {editing && (
                <div className="profile-edit-actions">

                  <button
                    type="button"
                    className="cancel-btn"
                    onClick={() => setEditing(false)}
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="save-profile-btn"
                  >
                    Save Changes
                  </button>

                </div>
              )}

            </form>

          </section>

          {/* Account Security */}
          <section className="profile-card">

            <div className="profile-section-heading">

              <div>
                <h2>Account Security</h2>
                <p>
                  Manage your password and account access.
                </p>
              </div>

            </div>

            <div className="security-row">

              <div>
                <h3>Password</h3>
                <p>
                  Secured with Django Auth
                </p>
              </div>

              <button className="security-btn" onClick={() => alert("Password reset link sent to your email!")}>
                Change Password
              </button>

            </div>

            <div className="security-row">

              <div>
                <h3>Session</h3>
                <p>
                  Your current session is active.
                </p>
              </div>

              <span className="session-active">
                Active
              </span>

            </div>

          </section>

          {/* Logout */}
          <section className="profile-card logout-card">

            <div>
              <h2>Sign out</h2>

              <p>
                Sign out from your current Apically account.
              </p>
            </div>

            <button
              className="logout-btn"
              onClick={handleLogout}
            >
              Logout
            </button>

          </section>

        </div>

      </main>

    </div>
  );
}

export default Profile;