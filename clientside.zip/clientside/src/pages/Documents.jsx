import { useState } from "react";
import { Link } from "react-router-dom";
import "./Documents.css";

function Documents() {
  const [search, setSearch] = useState("");

  const documents = [
    {
      name: "Company Overview",
      type: "PDF",
      category: "Company",
      description:
        "Company background, mission, vision, values and organizational information.",
      updated: "Updated recently",
      size: "2.4 MB"
    },
    {
      name: "Product & Services Guide",
      type: "PDF",
      category: "Products",
      description:
        "Detailed information about company products, services and solutions.",
      updated: "Updated recently",
      size: "4.1 MB"
    },
    {
      name: "Customer Support Guide",
      type: "PDF",
      category: "Support",
      description:
        "Customer support information, common issues and resolution guidelines.",
      updated: "Updated recently",
      size: "1.8 MB"
    },
    {
      name: "Employee FAQ Document",
      type: "PDF",
      category: "FAQ",
      description:
        "Frequently asked questions and answers collected from company resources.",
      updated: "Updated recently",
      size: "1.2 MB"
    },
    {
      name: "Security & Privacy Policy",
      type: "PDF",
      category: "Security",
      description:
        "Information about security practices, privacy and data protection.",
      updated: "Updated recently",
      size: "2.7 MB"
    }
  ];

  const filteredDocuments = documents.filter((document) =>
    `${document.name} ${document.category} ${document.description}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div className="documents-page">

      <header className="documents-header">

        <div className="documents-brand">

          <Link to="/home" className="documents-back">
            ←
          </Link>

          <div className="documents-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>
            <span>Knowledge Base</span>
          </div>

        </div>

        <Link to="/chat" className="documents-chat-button">
          Ask Apically
        </Link>

      </header>

      <main className="documents-main">

        <section className="documents-intro">

          <div className="documents-intro-icon">
            📄
          </div>

          <div>
            <p>Knowledge Base</p>

            <h1>Company Documents</h1>

            <span>
              Explore information from company documents and PDF resources.
            </span>
          </div>

        </section>

        <div className="documents-toolbar">

          <div className="documents-search">

            <span>⌕</span>

            <input
              type="text"
              placeholder="Search documents..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />

          </div>

          <button className="upload-document-button">
            + Upload Document
          </button>

        </div>

        <section className="documents-section">

          <div className="documents-section-heading">

            <div>
              <h2>Available Documents</h2>

              <p>
                Documents available in the Apically knowledge base.
              </p>
            </div>

            <span>
              {filteredDocuments.length} Documents
            </span>

          </div>

          <div className="documents-list">

            {filteredDocuments.length > 0 ? (

              filteredDocuments.map((document, index) => (

                <div className="document-card" key={index}>

                  <div className="document-icon">
                    PDF
                  </div>

                  <div className="document-content">

                    <div className="document-title-row">

                      <h3>{document.name}</h3>

                      <span className="document-category">
                        {document.category}
                      </span>

                    </div>

                    <p>
                      {document.description}
                    </p>

                    <div className="document-meta">

                      <span>
                        📄 {document.type}
                      </span>

                      <span>
                        {document.size}
                      </span>

                      <span>
                        {document.updated}
                      </span>

                    </div>

                  </div>

                  <button className="document-view-button">
                    View
                  </button>

                </div>

              ))

            ) : (

              <div className="documents-empty">

                <div>🔍</div>

                <h3>No documents found</h3>

                <p>
                  Try searching with a different keyword.
                </p>

              </div>

            )}

          </div>

        </section>

        <section className="documents-info">

          <div className="documents-info-icon">
            ✦
          </div>

          <div>
            <h3>Ask Apically about these documents</h3>

            <p>
              Apically can answer questions using information from
              supported company documents and knowledge-base resources.
            </p>
          </div>

          <Link to="/chat">
            Start Chat →
          </Link>

        </section>

      </main>

    </div>
  );
}

export default Documents;