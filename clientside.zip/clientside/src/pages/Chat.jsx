import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./Chat.css";

function Chat() {
  const [message, setMessage] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const [messages, setMessages] = useState([
    {
      sender: "bot",
      text: "Hello! I'm Apically AI Assistant. How can I help you today?",
      time: "Now",
    },
  ]);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        setCurrentUser(parsed);
        fetchHistory(parsed.id);
      } catch (e) {
        console.error("Error parsing saved user:", e);
      }
    }
  }, []);

  const fetchHistory = async (userId) => {
    try {
      const res = await fetch(`http://127.0.0.1:8000/api/history/?user_id=${userId}`);
      if (!res.ok) return;
      const data = await res.json();
      if (data.history && data.history.length > 0) {
        const formatted = [
          {
            sender: "bot",
            text: "Hello! I'm Apically AI Assistant. How can I help you today?",
            time: "System",
          },
        ];
        data.history.forEach((item) => {
          formatted.push({
            sender: "user",
            text: item.user_message,
            time: item.created_at,
          });
          formatted.push({
            sender: "bot",
            text: item.bot_reply,
            time: item.created_at,
          });
        });
        setMessages(formatted);
      }
    } catch (err) {
      console.error("Failed to load chat history:", err);
    }
  };

  const sendMessage = async (e) => {
    e.preventDefault();

    if (!message.trim() || isThinking) return;

    const userText = message;
    const newMessage = {
      sender: "user",
      text: userText,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((previous) => [...previous, newMessage]);
    setMessage("");
    setIsThinking(true);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/chat/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userText,
          user_id: currentUser ? currentUser.id : null,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      setMessages((previous) => [
        ...previous,
        {
          sender: "bot",
          text: data.reply || "No reply received.",
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } catch (err) {
      console.error("Chat API error:", err);
      setMessages((previous) => [
        ...previous,
        {
          sender: "bot",
          text: "Error: Unable to connect to backend server. Make sure Django server is running.",
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="chat-page">

      {/* Header */}
      <header className="chat-header">

        <div className="chat-brand">
          <Link to="/home" className="chat-back">
            ←
          </Link>

          <div className="chat-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>

            <span>
              <i></i>
              AI Assistant Online
            </span>
          </div>
        </div>

        <div className="chat-actions">

          <Link to="/history">
            History
          </Link>

          <Link to="/profile" className="chat-avatar" title={currentUser ? currentUser.name : "Profile"}>
            {currentUser && currentUser.name ? currentUser.name[0].toUpperCase() : "A"}
          </Link>

        </div>

      </header>

      {/* Chat Area */}
      <main className="chat-main">

        <div className="chat-content">

          <div className="chat-title">
            <h1>AI Assistant</h1>

            <p>
              Ask anything about our company, products, services,
              FAQs or documents.
            </p>
          </div>

          {/* Messages */}
          <div className="messages-container">

            {messages.map((msg, index) => (

              <div
                key={index}
                className={`message-row ${msg.sender}`}
              >

                {msg.sender === "bot" && (
                  <div className="message-avatar">
                    A
                  </div>
                )}

                <div className="message-wrapper">

                  <div className="message-bubble">
                    {msg.text}
                  </div>

                  <span className="message-time">
                    {msg.time}
                  </span>

                </div>

                {msg.sender === "user" && (
                  <div className="message-avatar user-avatar">
                    A
                  </div>
                )}

              </div>

            ))}

          </div>

          {/* Typing indicator */}
          {isThinking && (
            <div className="typing-indicator" style={{ display: "flex" }}>
              <span></span>
              <span></span>
              <span></span>
              Apically is thinking...
            </div>
          )}

          {/* Message Input */}
          <form className="message-form" onSubmit={sendMessage}>

            <input
              type="text"
              placeholder="Ask Apically anything..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              disabled={isThinking}
            />

            <button type="submit" disabled={isThinking}>
              Send
            </button>

          </form>

          <p className="chat-disclaimer">
            Apically AI may occasionally provide inaccurate information.
            Please verify important information.
          </p>

        </div>

      </main>

    </div>
  );
}

export default Chat;