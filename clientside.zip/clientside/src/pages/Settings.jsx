import { useState } from "react";
import { Link } from "react-router-dom";
import "./Settings.css";

function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [systemNotifications, setSystemNotifications] = useState(true);
  const [sound, setSound] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className="settings-page">

      <header className="settings-header">
        <div className="settings-brand">

          <Link to="/home" className="settings-back">
            ←
          </Link>

          <div className="settings-logo">
            A
          </div>

          <div>
            <h2>Apically</h2>
            <span>Settings</span>
          </div>

        </div>

        <Link to="/profile" className="settings-avatar">
          A
        </Link>
      </header>

      <main className="settings-main">

        <section className="settings-title">
          <div className="settings-title-icon">
            ⚙
          </div>

          <div>
            <p>Account Preferences</p>
            <h1>Settings</h1>
            <span>
              Manage your Apically preferences and account settings.
            </span>
          </div>
        </section>

        {/* Notifications */}

        <section className="settings-section">

          <div className="settings-section-heading">
            <div className="settings-section-icon">
              🔔
            </div>

            <div>
              <h2>Notifications</h2>
              <p>Control how Apically notifies you.</p>
            </div>
          </div>

          <div className="setting-item">
            <div>
              <h3>Push Notifications</h3>
              <p>Receive notifications about new messages and activity.</p>
            </div>

            <label className="switch">
              <input
                type="checkbox"
                checked={notifications}
                onChange={() => setNotifications(!notifications)}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div>
              <h3>System Notifications</h3>
              <p>Receive important system and account notifications.</p>
            </div>

            <label className="switch">
              <input
                type="checkbox"
                checked={systemNotifications}
                onChange={() =>
                  setSystemNotifications(!systemNotifications)
                }
              />
              <span className="slider"></span>
            </label>
          </div>

        </section>

        {/* Chat Preferences */}

        <section className="settings-section">

          <div className="settings-section-heading">
            <div className="settings-section-icon">
              💬
            </div>

            <div>
              <h2>Chat Preferences</h2>
              <p>Customize your chat experience.</p>
            </div>
          </div>

          <div className="setting-item">
            <div>
              <h3>Message Sounds</h3>
              <p>Play a sound when new messages arrive.</p>
            </div>

            <label className="switch">
              <input
                type="checkbox"
                checked={sound}
                onChange={() => setSound(!sound)}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div>
              <h3>Show Message Timestamps</h3>
              <p>Display the time when each message was sent.</p>
            </div>

            <label className="switch">
              <input type="checkbox" defaultChecked />
              <span className="slider"></span>
            </label>
          </div>

        </section>

        {/* Appearance */}

        <section className="settings-section">

          <div className="settings-section-heading">
            <div className="settings-section-icon">
              🎨
            </div>

            <div>
              <h2>Appearance</h2>
              <p>Customize how Apically looks.</p>
            </div>
          </div>

          <div className="setting-item">

            <div>
              <h3>Dark Mode</h3>
              <p>Use a darker interface for a comfortable experience.</p>
            </div>

            <label className="switch">
              <input
                type="checkbox"
                checked={darkMode}
                onChange={() => setDarkMode(!darkMode)}
              />
              <span className="slider"></span>
            </label>

          </div>

        </section>

        {/* Privacy */}

        <section className="settings-section">

          <div className="settings-section-heading">
            <div className="settings-section-icon">
              🛡️
            </div>

            <div>
              <h2>Privacy & Security</h2>
              <p>Manage your account security preferences.</p>
            </div>
          </div>

          <div className="settings-action">
            <div>
              <h3>Change Password</h3>
              <p>Update your account password.</p>
            </div>

            <button>
              Change
            </button>
          </div>

          <div className="settings-action">
            <div>
              <h3>Active Sessions</h3>
              <p>Review devices where your account is currently active.</p>
            </div>

            <button>
              View
            </button>
          </div>

        </section>

        <div className="settings-note">
          <span>🔒</span>

          <div>
            <h3>Your privacy matters</h3>
            <p>
              Your account and conversation data should be protected.
              Authentication and security enforcement will be handled
              by the backend.
            </p>
          </div>
        </div>

      </main>

    </div>
  );
}

export default Settings;